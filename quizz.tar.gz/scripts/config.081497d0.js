angular.module('application.config', [])

.constant('appConfiguration', {})

;